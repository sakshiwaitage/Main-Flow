function appendValue(value) {
    document.getElementById("display").value += value;
}
function appendOperator(operator) {
    let display = document.getElementById("display");
    let lastChar = display.value.slice(-1);
    if ('+-*/'.includes(lastChar)) {
        return;
    }
    display.value += operator;
}
function appendDecimal() {
    let display = document.getElementById("display");
    let parts = display.value.split(/[-+*/]/);
    let lastPart = parts[parts.length - 1];
    if (!lastPart.includes(".")) {
        display.value += ".";
    }
}
function clearDisplay() {
    document.getElementById("display").value = "";
}
function calculate() {
    let display = document.getElementById("display");
    try {
        let result = eval(display.value);
        if (!isFinite(result)) {
            display.value = "Error";
        } else {
            display.value = result;
        }
    } catch (error) {
        display.value = "Error";
    }
}