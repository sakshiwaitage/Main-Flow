<?php
echo "PHP is working without XAMPP!";
?>
