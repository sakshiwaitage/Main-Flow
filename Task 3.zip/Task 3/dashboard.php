<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .logout-btn {
            background-color: red;
            color: white;
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>

<h2>Welcome, <?php echo $_SESSION["username"]; ?>!</h2>
<p>Your email: <?php echo $_SESSION["email"]; ?></p>

<!-- Logout Button -->
<form action="logout.php" method="POST">
    <button class="logout-btn" type="submit">Logout</button>
</form>

</body>
</html>
